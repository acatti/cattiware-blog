####################################################
###    CATTIWARE PYCALC - Auth: Alessandro Catti ###
###                DATA:    31/10/2019           ###
###             LICENZA:    SENZA LICENZA        ###
###  NOME DEL PROGRAMMA:    calc.py              ###
####################################################

from math import sqrt

####### DEFINIZIONE FUNZIONI
## ---> CALCOLO
def div(x,y):  # LO SCOPO DI QUESTA FUNZIONE NON E' TANTO FARE LA DIVISIONE....
    if(y!=0):  # ...MA E' UN CONTROLLO PER GESTIRE L'ERRORE DELLA "DIVISIONE PER ZERO"
        return x / y
    else:
      print("ERRORE 1: DIVISIONE PER ZERO, USCITA DAL PROGRAMMA... :(")
      exit()
	  
def fatt(x):  #FATTORIALE
	if(x==0):
		return 1 #IL FATTORIALE DI ZERO E' SEMPRE UNO
	return x*fatt(x-1) #FUNZIONE RICORSIVA
	
### ---> PROGRAMMA
def benvenuto(): #MESSAGGIO DI BENVENUTO CHE MOSTRA E RACCOGLIE LE IMPOSTAZIONI
    opz=""
    print(" ")
    print("<-----------------SCIENTIFICA----------------->")
    print("|  - RADICE QUADRATA:       DIGITA    \"sqrt\"; |")
    print("|  - QUOZIENTE:             DIGITA      \"//\"; |")
    print("|  - FATTORIALE:            DIGITA       \"!\"; |")
    print("<--------------------OPZIONI------------------>")
    print("|  - AZZERARE IL RISULTATO: DIGITA      \"ce\"; |")
    print("|  - ESCI:                  DIGITA    \"exit\"; |")
    print("<--------------------------------------------->")
    while opz==None or opz=="" or opz==" ":
        opz = input("INPUT (OPERATORI BASE [ + ; - ; * ; / ; ^ ]): ")
    print(" ")
    if(opz=="exit"):
        exit()
    return opz

def calcolatrice(x,opz): #LA FUNZIONE DI CALCOLO
    if(opz != "ce"): #INUTILE INSERIRE IL SECONDO NUMERO...
        y=None
        while y==None or y=="" or y==" ":
            y=input("INSERIRE UN NUMERO (per \"π\" DIGITA \"pi\"): ")  #Y E' IL SECONDO NUMERO
        if(y=="pi"):
            y=3.14159265358979323846
        try:
            y=float(y)
        except:
            print("ERRORE 2: INSERIMENTO ERRATO, USCITA DAL PROGRAMMA... :(")
            exit()
            
	#GESTIONE DEGLI OPERANDI
    if(opz == "+"):
        y=x+y
    elif(opz == "-"):
        y=x-y
    elif(opz == "*"):
        y=x*y
    elif(opz == "/"):
        y=div(x,y)
    elif(opz == "^"):
        y=x**y
    elif(opz == "sqrt"):
        y=sqrt(y)
    elif(opz == "//"):
        y=x//y
    elif(opz == "!"):
        y=fatt(y)
    elif(opz == "ce"):
        y=0 #AZZERAMENTO DEL RISULTATO
    print("RISULTATO: "+str(y))
    return y

#####PROGRAMMA PRINCIPALE

x=None
while x==None or x=="" or x==" ": #PICCOLO CONTROLLO DI "x"
    x=input("CALCOLATRICE ---> INSERIRE UN NUMERO PER INIZIARE (per \"π\" DIGITA \"pi\"): ")
if(x=="pi"):
   x=3.14159265358979323846       # π ---> PIGRECO ---> "x" CONTIENE IL SUO VALORE
try:                              #GESTICO LE ECCEZIONI CHE NON SONO RIUSCITO A CONTROLLARE NEL "while"
    x=float(x)  # DATO CHE "x" E' UNA STRINGA, AL MOMENTO DELL'INSERIMENTO, LO CONVERTO IN "VIRGOLA MOBILE"
except:         # MA SE NON E' UN NUMERO, IL DATO CONTENUTO NELLA STRINGA, INTERROMPO IL PROGRAMMA PER PREVENIRE ERRORI
    print("ERRORE 2: INSERIMENTO ERRATO, USCITA DAL PROGRAMMA... :(")
    exit() # exit() ---> FUNZIONE PER USCIRE DAL PROGRAMMA...

# PROCEDO CON L'ESECUZIONE DELLA CALCOLATRICE
opz = True   # HO SETTATO "opz" COME "True",
while opz:   # IN QUESTO MODO RIPETO IL PROGRAMMA FINO A QUANDO "opz" NON DIVENTA FALSA ("False")
    opz=benvenuto()  #STAMPO IL MESSAGGIO DI BENVENUTO CHE MI PERMETTERA' DI CONOSCERE L'OPERANDO INSERITO DALL'UTENTE
    x=calcolatrice(x,opz) #ED ESEGUO IL CALCOLO
